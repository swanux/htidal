#!/bin/sh +e

/usr/share/htidal/htidal.py
