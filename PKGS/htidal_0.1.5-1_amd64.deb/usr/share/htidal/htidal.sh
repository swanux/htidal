#!/bin/sh +e

/usr/share/htidal/HTidal.py
